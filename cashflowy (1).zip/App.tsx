
import React, { useState, useEffect } from 'react';
import { NavigationTab, FinancialState, Transaction, Card, Goal, UserAccount } from './types';
import { INITIAL_STATE } from './constants';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import TransactionManager from './components/TransactionManager';
import CardManager from './components/CardManager';
import GoalsManager from './components/GoalsManager';
import AIChat from './components/AIChat';
import RendaPaz from './components/RendaPaz';
import Settings from './components/Settings';
import Support from './components/Support';
import Login from './components/Login';
import AdminPanel from './components/AdminPanel';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<NavigationTab>(NavigationTab.Dashboard);
  const [currentUser, setCurrentUser] = useState<string | null>(() => {
    return localStorage.getItem('cashflowy_session');
  });

  const [state, setState] = useState<FinancialState>(INITIAL_STATE);
  const [showMobileNotice, setShowMobileNotice] = useState<boolean>(() => {
    return localStorage.getItem('cashflowy_mobile_notice_dismissed') !== 'true';
  });

  // Carregar dados específicos do usuário logado
  useEffect(() => {
    if (currentUser) {
      const users: UserAccount[] = JSON.parse(localStorage.getItem('cashflowy_accounts') || '[]');
      const userProfile = users.find(u => u.username === currentUser);
      const savedData = localStorage.getItem(`cashflowy_data_${currentUser}`);
      
      if (savedData) {
        setState(JSON.parse(savedData));
      } else if (userProfile) {
        setState({
          ...INITIAL_STATE,
          userSettings: userProfile.settings
        });
      }
    } else {
      setState(INITIAL_STATE);
    }
  }, [currentUser]);

  // Sincronizar dark mode e persistência de dados
  useEffect(() => {
    if (currentUser) {
      localStorage.setItem(`cashflowy_data_${currentUser}`, JSON.stringify(state));
      
      const users: UserAccount[] = JSON.parse(localStorage.getItem('cashflowy_accounts') || '[]');
      const updatedUsers = users.map(u => 
        u.username === currentUser ? { ...u, settings: state.userSettings } : u
      );
      localStorage.setItem('cashflowy_accounts', JSON.stringify(updatedUsers));

      if (state.userSettings.darkMode) {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
    }
  }, [state, currentUser]);

  const handleLogin = (username: string) => {
    localStorage.setItem('cashflowy_session', username);
    setCurrentUser(username);
  };

  const handleLogout = () => {
    localStorage.removeItem('cashflowy_session');
    setCurrentUser(null);
    setState(INITIAL_STATE);
    setActiveTab(NavigationTab.Dashboard);
  };

  const dismissMobileNotice = () => {
    setShowMobileNotice(false);
    localStorage.setItem('cashflowy_mobile_notice_dismissed', 'true');
  };

  const handleAddTransaction = (t: Omit<Transaction, 'id'>) => {
    const newTransaction: Transaction = { ...t, id: Date.now().toString() };
    setState(prev => ({
      ...prev,
      transactions: [newTransaction, ...prev.transactions]
    }));
  };

  const handleUpdateTransaction = (updatedTransaction: Transaction) => {
    setState(prev => ({
      ...prev,
      transactions: prev.transactions.map(t => t.id === updatedTransaction.id ? updatedTransaction : t)
    }));
  };

  const handleDeleteTransaction = (id: string) => {
    if (window.confirm('Tem certeza que deseja excluir esta transação? Esta ação não pode ser desfeita.')) {
      setState(prev => {
        const newState = {
          ...prev,
          transactions: prev.transactions.filter(t => t.id !== id)
        };
        if (currentUser) {
          localStorage.setItem(`cashflowy_data_${currentUser}`, JSON.stringify(newState));
        }
        return newState;
      });
    }
  };

  const handleUpdateCard = (card: Card) => {
    setState(prev => ({
      ...prev,
      cards: prev.cards.map(c => c.id === card.id ? card : c)
    }));
  };

  const handleAddCard = (card: Omit<Card, 'id'>) => {
    const newCard: Card = { ...card, id: 'c' + Date.now() };
    setState(prev => ({
      ...prev,
      cards: [...prev.cards, newCard]
    }));
  };

  const handleAddGoal = (goal: Omit<Goal, 'id'>) => {
    const newGoal: Goal = { ...goal, id: 'g' + Date.now() };
    setState(prev => ({
      ...prev,
      goals: [...prev.goals, newGoal]
    }));
  };

  if (!currentUser) {
    return <Login onLogin={handleLogin} isDarkMode={window.matchMedia('(prefers-color-scheme: dark)').matches} />;
  }

  const renderContent = () => {
    switch (activeTab) {
      case NavigationTab.Dashboard:
        return <Dashboard state={state} onAddTransaction={handleAddTransaction} onUpdateTransaction={handleUpdateTransaction} onLogout={handleLogout} />;
      case NavigationTab.Transactions:
        return <TransactionManager state={state} onAddTransaction={handleAddTransaction} onUpdateTransaction={handleUpdateTransaction} />;
      case NavigationTab.Cards:
        return <CardManager state={state} onUpdateCard={handleUpdateCard} onAddCard={handleAddCard} />;
      case NavigationTab.Goals:
        return <GoalsManager state={state} onAddGoal={handleAddGoal} />;
      case NavigationTab.AI:
        return <AIChat state={state} />;
      case NavigationTab.RendaPaz:
        return <RendaPaz />;
      case NavigationTab.Settings:
        return <Settings state={state} setState={setState} handleLogout={handleLogout} />;
      case NavigationTab.Support:
        return <Support />;
      case NavigationTab.AdminPanel:
        return currentUser === 'adm' ? <AdminPanel /> : <Dashboard state={state} onAddTransaction={handleAddTransaction} onUpdateTransaction={handleUpdateTransaction} onLogout={handleLogout} />;
      default:
        return <Dashboard state={state} onAddTransaction={handleAddTransaction} onUpdateTransaction={handleUpdateTransaction} onLogout={handleLogout} />;
    }
  };

  return (
    <div className="flex flex-col md:flex-row h-screen overflow-hidden bg-slate-50 dark:bg-slate-950 transition-colors duration-300">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} state={state} setState={setState} handleLogout={handleLogout} />
      
      <main className="flex-1 overflow-y-auto p-4 md:p-8 pt-20 md:pt-8 custom-scrollbar text-slate-900 dark:text-slate-100">
        {showMobileNotice && (
          <div className="md:hidden mb-6 relative overflow-hidden bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl p-4 text-white shadow-lg animate-in fade-in slide-in-from-top-4 duration-500">
            <div className="flex items-start gap-3">
              <div className="bg-white/20 p-2 rounded-xl">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                </svg>
              </div>
              <div className="flex-1 pr-6">
                <p className="text-xs font-bold uppercase tracking-wider opacity-80 mb-0.5">Dica CashFlowy</p>
                <p className="text-sm font-medium leading-tight">
                  Para acesso total às funções, use o computador ou pelo navegador do celular entre no modo para computador.
                </p>
              </div>
              <button 
                onClick={dismissMobileNotice}
                className="absolute top-2 right-2 p-1.5 hover:bg-white/10 rounded-lg transition-colors"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
          </div>
        )}

        {renderContent()}
      </main>
      
      {/* Mobile Top Header */}
      <div className="md:hidden fixed top-0 left-0 right-0 h-16 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between px-6 z-40 transition-colors">
        <h1 className="text-xl font-bold text-blue-600 flex items-center gap-2">
          CashFlowy
        </h1>
        <div className="flex items-center gap-1">
          <button 
            onClick={() => setState(prev => ({ ...prev, userSettings: { ...prev.userSettings, darkMode: !prev.userSettings.darkMode } }))}
            className="p-2 text-slate-500 dark:text-slate-400"
          >
            {state.userSettings.darkMode ? (
              <svg className="w-5 h-5 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 3v1m0 18v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" />
              </svg>
            ) : (
              <svg className="w-5 h-5 text-slate-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" />
              </svg>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default App;
