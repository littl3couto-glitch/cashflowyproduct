
export const CATEGORIES = {
  income: ['Salário', 'Investimentos', 'Freelance', 'Outros'],
  expense: ['Mercado', 'Uber', 'Aluguel', 'Lazer', 'Saúde', 'Educação', 'Outros']
};

export const CARD_COLORS = [
  'bg-blue-600',
  'bg-purple-600',
  'bg-slate-800',
  'bg-rose-600',
  'bg-emerald-600',
  'bg-amber-500'
];

export const INITIAL_STATE = {
  transactions: [],
  cards: [],
  goals: [],
  userSettings: {
    currency: 'R$',
    familyMode: false,
    darkMode: false,
    name: 'Usuário'
  }
};
