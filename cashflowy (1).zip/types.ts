
export type TransactionType = 'income' | 'expense';

export interface Transaction {
  id: string;
  description: string;
  amount: number;
  type: TransactionType;
  category: string;
  date: string;
  cardId?: string;
}

export interface Card {
  id: string;
  name: string;
  limit: number;
  closingDay: number;
  dueDay: number;
  color: string;
}

export interface Goal {
  id: string;
  name: string;
  targetAmount: number;
  currentAmount: number;
  deadline: string;
  icon: string;
}

export interface UserSettings {
  currency: string;
  familyMode: boolean;
  darkMode: boolean;
  name: string;
}

export interface UserAccount {
  username: string;
  email: string;
  passwordHash: string;
  settings: UserSettings;
}

export interface FinancialState {
  transactions: Transaction[];
  cards: Card[];
  goals: Goal[];
  userSettings: UserSettings;
}

export enum NavigationTab {
  Dashboard = 'dashboard',
  Transactions = 'transactions',
  Cards = 'cards',
  Goals = 'goals',
  AI = 'ai',
  RendaPaz = 'renda_paz',
  Settings = 'settings',
  Support = 'support',
  AdminPanel = 'admin_panel'
}
