
import { GoogleGenAI } from "@google/genai";
import { FinancialState } from "../types";

// Always use const ai = new GoogleGenAI({apiKey: process.env.API_KEY}); strictly obtained from environment variables.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getFinancialAdvice = async (state: FinancialState, userQuery?: string) => {
  // Task involves financial reasoning, using gemini-3-pro-preview for higher quality advice.
  const model = 'gemini-3-pro-preview';
  
  const summary = {
    userName: state.userSettings.name,
    totalIncome: state.transactions.filter(t => t.type === 'income').reduce((acc, t) => acc + t.amount, 0),
    totalExpense: state.transactions.filter(t => t.type === 'expense').reduce((acc, t) => acc + t.amount, 0),
    categories: state.transactions.reduce((acc: any, t) => {
      acc[t.category] = (acc[t.category] || 0) + t.amount;
      return acc;
    }, {}),
    cards: state.cards.map(c => {
      const used = state.transactions.filter(t => t.cardId === c.id).reduce((acc, t) => acc + t.amount, 0);
      return { name: c.name, limit: c.limit, used, available: c.limit - used };
    }),
    goals: state.goals.map(g => ({ 
      name: g.name, 
      progress: ((g.currentAmount / g.targetAmount) * 100).toFixed(1) + '%',
      remaining: g.targetAmount - g.currentAmount
    })),
  };

  const context = `
    Você é o CashFlowy AI, o consultor financeiro pessoal de ${summary.userName}.
    
    DADOS ATUAIS DE ${summary.userName.toUpperCase()}:
    - Saldo Atual (Entradas - Saídas): ${state.userSettings.currency} ${(summary.totalIncome - summary.totalExpense).toFixed(2)}
    - Gastos Totais: ${state.userSettings.currency} ${summary.totalExpense.toFixed(2)}
    - Distribuição por Categoria: ${JSON.stringify(summary.categories)}
    - Status dos Cartões: ${JSON.stringify(summary.cards)}
    - Progresso das Metas: ${JSON.stringify(summary.goals)}

    DIRETRIZES DE PERSONALIDADE:
    1. Sempre comece ou termine mensagens importantes chamando o usuário pelo nome: ${summary.userName}.
    2. Seja analítico: Se os gastos em uma categoria (como Lazer ou Uber) estiverem altos em relação à renda, comente de forma educada mas direta.
    3. Alerte sobre riscos: Se um cartão estiver com mais de 80% do limite usado, avise.
    4. Incentive metas: Se o progresso de uma meta estiver estagnado, sugira um pequeno aporte.
    5. Responda em Português Brasileiro, de forma empática, motivadora e extremamente inteligente.

    OBJETIVO:
    Analise o perfil acima e responda à pergunta do usuário ou dê um panorama estratégico para a saúde financeira dele.
  `;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: userQuery 
        ? `${context}\n\nPergunta específica de ${summary.userName}: ${userQuery}` 
        : `${context}\n\n${summary.userName} solicitou uma análise geral dos hábitos. Por favor, forneça um resumo executivo da vida financeira dele agora.`,
      config: {
        temperature: 0.7,
        topP: 0.8,
        systemInstruction: `Você é o CashFlowy AI. Seu tom é de um mentor financeiro experiente. Sempre use o nome ${summary.userName}.`
      }
    });

    return response.text || `Desculpe, ${summary.userName}, não consegui processar sua análise agora.`;
  } catch (error) {
    console.error("Gemini Error:", error);
    return `Olá ${summary.userName}, tive um probleminha técnico para acessar seu relatório agora. Pode tentar de novo em instantes?`;
  }
};
