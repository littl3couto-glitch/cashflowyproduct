
import React, { useState, useMemo, useEffect } from 'react';
import { UserAccount, FinancialState } from '../types';

const AdminPanel: React.FC = () => {
  // Usando state para permitir atualização imediata da UI após exclusão
  const [accounts, setAccounts] = useState<UserAccount[]>(() => {
    return JSON.parse(localStorage.getItem('cashflowy_accounts') || '[]');
  });

  const [ipLedger, setIpLedger] = useState<Record<string, string>>(() => {
    return JSON.parse(localStorage.getItem('cashflowy_ip_ledger') || '{}');
  });

  // Função para deletar conta
  const handleDeleteAccount = (username: string) => {
    if (username === 'adm') {
      alert("A conta mestre do administrador não pode ser excluída.");
      return;
    }

    if (window.confirm(`ATENÇÃO: Você está prestes a apagar permanentemente a conta @${username}. Todos os dados financeiros e históricos serão destruídos. Continuar?`)) {
      // 1. Remover da lista de contas
      const updatedAccounts = accounts.filter(u => u.username !== username);
      localStorage.setItem('cashflowy_accounts', JSON.stringify(updatedAccounts));
      setAccounts(updatedAccounts);

      // 2. Remover dados financeiros
      localStorage.removeItem(`cashflowy_data_${username}`);

      // 3. Limpar IPs vinculados a esse usuário
      const updatedIpLedger = { ...ipLedger };
      Object.keys(updatedIpLedger).forEach(ip => {
        if (updatedIpLedger[ip] === username) {
          delete updatedIpLedger[ip];
        }
      });
      localStorage.setItem('cashflowy_ip_ledger', JSON.stringify(updatedIpLedger));
      setIpLedger(updatedIpLedger);
    }
  };

  // Agrega dados financeiros detalhados de cada usuário
  const userStats = useMemo(() => {
    return accounts.map(user => {
      const userDataStr = localStorage.getItem(`cashflowy_data_${user.username}`);
      let income = 0;
      let expense = 0;

      if (userDataStr) {
        try {
          const data: FinancialState = JSON.parse(userDataStr);
          income = data.transactions
            .filter(t => t.type === 'income')
            .reduce((acc, t) => acc + t.amount, 0);
          expense = data.transactions
            .filter(t => t.type === 'expense')
            .reduce((acc, t) => acc + t.amount, 0);
        } catch (e) {
          console.error(`Erro ao processar dados de ${user.username}`);
        }
      }

      // Encontrar o IP vinculado a este usuário
      const userIp = Object.keys(ipLedger).find(key => ipLedger[key] === user.username) || 'Não registrado';

      return {
        ...user,
        totalIncome: income,
        totalExpense: expense,
        netBalance: income - expense,
        lastIp: userIp
      };
    });
  }, [accounts, ipLedger]);

  const globalStats = useMemo(() => {
    const totalVolume = userStats.reduce((acc, u) => acc + u.totalIncome + u.totalExpense, 0);
    const totalBalance = userStats.reduce((acc, u) => acc + u.netBalance, 0);
    return {
      totalUsers: accounts.length,
      ipCount: Object.keys(ipLedger).length,
      globalVolume: totalVolume,
      globalBalance: totalBalance
    };
  }, [userStats, accounts, ipLedger]);

  return (
    <div className="space-y-8 pb-20 md:pb-8 animate-in fade-in duration-500">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-slate-800 text-white rounded-full text-[10px] font-black uppercase tracking-widest mb-2">
            <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-pulse" />
            Terminal do Administrador
          </div>
          <h2 className="text-3xl font-black text-slate-800 dark:text-white tracking-tighter">Monitoramento Global</h2>
          <p className="text-slate-500 dark:text-slate-400 font-medium">Análise de fluxo e performance de todos os perfis.</p>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <StatCard 
          title="Usuários Ativos" 
          value={globalStats.totalUsers} 
          icon={<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" /></svg>}
          color="bg-blue-600"
        />
        <StatCard 
          title="Volume Transacionado" 
          value={`R$ ${globalStats.globalVolume.toLocaleString('pt-BR', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`} 
          icon={<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" /></svg>}
          color="bg-emerald-600"
        />
        <StatCard 
          title="IPs Rastreados" 
          value={globalStats.ipCount} 
          icon={<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" /></svg>}
          color="bg-slate-800"
        />
        <StatCard 
          title="Saldo em Rede" 
          value={`R$ ${globalStats.globalBalance.toLocaleString('pt-BR', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`} 
          icon={<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>}
          color="bg-indigo-600"
        />
      </div>

      <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-xl overflow-hidden">
        <div className="p-8 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <h3 className="text-xl font-bold text-slate-800 dark:text-white">Auditoria de Contas</h3>
          <span className="px-3 py-1 bg-blue-100 dark:bg-blue-900/40 text-blue-600 dark:text-blue-400 rounded-full text-[10px] font-black uppercase tracking-widest">Acesso de Superuser</span>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50 dark:bg-slate-800/50">
              <tr>
                <th className="px-8 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Usuário / IP</th>
                <th className="px-8 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">E-mail</th>
                <th className="px-8 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest text-right">Ganhos</th>
                <th className="px-8 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest text-right">Gastos</th>
                <th className="px-8 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest text-right">Saldo</th>
                <th className="px-8 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest text-center">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {userStats.map(u => (
                <tr key={u.username} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors group">
                  <td className="px-8 py-5">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-2xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center font-black text-slate-500 group-hover:bg-blue-600 group-hover:text-white transition-all">
                        {u.settings.name.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <p className="font-bold text-slate-800 dark:text-slate-200 leading-none mb-1">{u.settings.name}</p>
                        <div className="flex items-center gap-2">
                          <span className="text-[9px] font-bold text-slate-400 uppercase tracking-tighter">@{u.username}</span>
                          <span className="text-[9px] font-mono text-blue-500 dark:text-blue-400 font-bold bg-blue-50 dark:bg-blue-900/20 px-1.5 rounded">
                            {u.lastIp}
                          </span>
                        </div>
                      </div>
                    </div>
                  </td>
                  <td className="px-8 py-5">
                    <a href={`mailto:${u.email}`} className="text-sm font-medium text-slate-600 dark:text-slate-400 hover:text-blue-600 transition-colors">
                      {u.email}
                    </a>
                  </td>
                  <td className="px-8 py-5 text-right font-black text-emerald-500 text-sm">
                    + {u.totalIncome.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                  </td>
                  <td className="px-8 py-5 text-right font-black text-rose-500 text-sm">
                    - {u.totalExpense.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                  </td>
                  <td className={`px-8 py-5 text-right font-black text-sm ${u.netBalance >= 0 ? 'text-slate-800 dark:text-slate-200' : 'text-rose-600'}`}>
                    {u.netBalance.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                  </td>
                  <td className="px-8 py-5 text-center">
                    {u.username !== 'adm' ? (
                      <button 
                        onClick={() => handleDeleteAccount(u.username)}
                        className="p-2 text-rose-300 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-900/20 rounded-xl transition-all active:scale-90"
                        title="Excluir Conta Permanentemente"
                      >
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                        </svg>
                      </button>
                    ) : (
                      <span className="text-[10px] font-black text-slate-300 uppercase tracking-widest">Admin</span>
                    )}
                  </td>
                </tr>
              ))}
              {userStats.length === 0 && (
                <tr>
                  <td colSpan={6} className="p-20 text-center opacity-40 italic font-medium">Nenhum registro encontrado no sistema.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-xl p-8">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-bold text-slate-800 dark:text-white">Registros de IP Ativos</h3>
          <Badge label="Tempo Real" color="bg-blue-50 text-blue-600" />
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {Object.entries(ipLedger).map(([ip, owner]) => (
            <div key={ip} className="p-4 rounded-2xl border border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 group hover:border-blue-500 transition-all">
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Ponto de Acesso</p>
              <p className="font-mono text-sm font-bold text-slate-800 dark:text-slate-200">{ip}</p>
              <div className="mt-2 flex items-center justify-between">
                <span className="text-xs font-bold text-slate-500 italic">@{owner}</span>
                <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              </div>
            </div>
          ))}
          {Object.keys(ipLedger).length === 0 && (
            <div className="col-span-full p-8 text-center text-slate-400 font-medium italic">Sem registros de IP ativos.</div>
          )}
        </div>
      </div>
    </div>
  );
};

const StatCard = ({ title, value, icon, color }: { title: string, value: any, icon: any, color: string }) => (
  <div className="bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm transition-all hover:shadow-md hover:-translate-y-1">
    <div className={`w-12 h-12 ${color} text-white rounded-2xl flex items-center justify-center mb-6 shadow-lg`}>
      {icon}
    </div>
    <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-1">{title}</p>
    <p className="text-2xl font-black text-slate-800 dark:text-white truncate">{value}</p>
  </div>
);

const Badge = ({ label, color = "bg-slate-100 text-slate-600" }: { label: string, color?: string }) => (
  <span className={`px-2.5 py-1 rounded-lg text-[9px] font-black uppercase tracking-widest ${color}`}>
    {label}
  </span>
);

export default AdminPanel;
