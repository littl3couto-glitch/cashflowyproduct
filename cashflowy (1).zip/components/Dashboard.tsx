
import React, { useMemo } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { FinancialState, Transaction } from '../types';

interface DashboardProps {
  state: FinancialState;
  onAddTransaction: (t: Omit<Transaction, 'id'>) => void;
  onUpdateTransaction?: (t: Transaction) => void;
  onLogout: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ state, onUpdateTransaction }) => {
  const { transactions, userSettings } = state;
  const isDark = userSettings.darkMode;

  const stats = useMemo(() => {
    const income = transactions.filter(t => t.type === 'income').reduce((acc, t) => acc + t.amount, 0);
    const expense = transactions.filter(t => t.type === 'expense').reduce((acc, t) => acc + t.amount, 0);
    return {
      balance: income - expense,
      income,
      expense,
      savingsRate: income > 0 ? Math.round(((income - expense) / income) * 100) : 0
    };
  }, [transactions]);

  const chartData = useMemo(() => {
    const last7Days = Array.from({ length: 7 }, (_, i) => {
      const d = new Date();
      d.setDate(d.getDate() - (6 - i));
      return d.toISOString().split('T')[0];
    });

    return last7Days.map(date => {
      const dailyIncome = transactions
        .filter(t => t.date === date && t.type === 'income')
        .reduce((acc, t) => acc + t.amount, 0);
      const dailyExpense = transactions
        .filter(t => t.date === date && t.type === 'expense')
        .reduce((acc, t) => acc + t.amount, 0);
      return {
        name: date.split('-')[2],
        income: dailyIncome,
        expense: dailyExpense
      };
    });
  }, [transactions]);

  const categoryData = useMemo(() => {
    const cats: Record<string, number> = {};
    transactions.filter(t => t.type === 'expense').forEach(t => {
      cats[t.category] = (cats[t.category] || 0) + t.amount;
    });
    return Object.entries(cats)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value);
  }, [transactions]);

  const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'];

  return (
    <div className="space-y-6 pb-24 md:pb-0 animate-in fade-in duration-700">
      <header className="flex items-center justify-between">
        <div>
          <h2 className="text-xl md:text-2xl font-black text-slate-800 dark:text-slate-100 tracking-tight">Oi, {userSettings.name.split(' ')[0]}!</h2>
          <p className="text-xs md:text-sm text-slate-500 font-semibold dark:text-slate-400">Aqui está o pulso das suas finanças.</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 flex items-center justify-center text-slate-400 shadow-sm">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
            </svg>
          </div>
        </div>
      </header>

      <div className="bg-blue-600 rounded-[2.5rem] p-10 text-white shadow-2xl shadow-blue-200 dark:shadow-none overflow-hidden relative">
        <div className="relative z-10">
          <p className="text-[10px] font-black opacity-70 mb-2 uppercase tracking-[0.2em]">Saldo em Conta</p>
          <h3 className="text-4xl md:text-5xl font-black tracking-tighter">{userSettings.currency} {stats.balance.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</h3>
          <div className="mt-10 flex gap-8">
            <div className="bg-white/10 px-6 py-3 rounded-2xl backdrop-blur-md">
              <p className="text-[9px] font-black opacity-70 uppercase mb-1 tracking-widest">Entradas</p>
              <p className="text-sm font-black text-emerald-300">+ {userSettings.currency} {stats.income.toLocaleString('pt-BR')}</p>
            </div>
            <div className="bg-white/10 px-6 py-3 rounded-2xl backdrop-blur-md">
              <p className="text-[9px] font-black opacity-70 uppercase mb-1 tracking-widest">Saídas</p>
              <p className="text-sm font-black text-rose-300">- {userSettings.currency} {stats.expense.toLocaleString('pt-BR')}</p>
            </div>
          </div>
        </div>
        <div className="absolute top-0 right-0 -mr-12 -mt-12 w-64 h-64 bg-white/10 rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-0 -ml-12 -mb-12 w-48 h-48 bg-blue-400/20 rounded-full blur-3xl" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] border border-slate-100 dark:border-slate-800 shadow-sm">
            <div className="flex items-center justify-between mb-8">
              <h3 className="font-black text-slate-800 dark:text-slate-100 uppercase text-xs tracking-widest">Fluxo Semanal</h3>
              <div className="flex gap-4">
                <span className="flex items-center gap-1.5 text-[10px] font-black uppercase text-emerald-500 tracking-tighter">
                  <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" /> Ganhos
                </span>
                <span className="flex items-center gap-1.5 text-[10px] font-black uppercase text-rose-500 tracking-tighter">
                  <div className="w-1.5 h-1.5 rounded-full bg-rose-500" /> Gastos
                </span>
              </div>
            </div>
            <div className="h-[220px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData}>
                  <defs>
                    <linearGradient id="colorInc" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#10b981" stopOpacity={0.15}/>
                      <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                    </linearGradient>
                    <linearGradient id="colorExp" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#ef4444" stopOpacity={0.15}/>
                      <stop offset="95%" stopColor="#ef4444" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="name" hide />
                  <YAxis hide />
                  <Tooltip 
                    contentStyle={{ borderRadius: '1rem', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                  />
                  <Area type="monotone" dataKey="income" stroke="#10b981" fill="url(#colorInc)" strokeWidth={4} />
                  <Area type="monotone" dataKey="expense" stroke="#ef4444" fill="url(#colorExp)" strokeWidth={4} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] border border-slate-100 dark:border-slate-800 shadow-sm overflow-hidden">
            <h3 className="font-black text-slate-800 dark:text-slate-100 uppercase text-xs tracking-widest mb-8">Concentração de Gastos</h3>
            <div className="space-y-6">
              {categoryData.slice(0, 4).map((cat, i) => (
                <div key={cat.name} className="flex items-center gap-5">
                  <div className="w-12 h-12 rounded-2xl flex items-center justify-center font-black text-lg" style={{ backgroundColor: `${COLORS[i % COLORS.length]}15`, color: COLORS[i % COLORS.length] }}>
                    {cat.name.charAt(0)}
                  </div>
                  <div className="flex-1">
                    <div className="flex justify-between mb-1.5">
                      <span className="text-xs font-black text-slate-700 dark:text-slate-300 uppercase tracking-tight">{cat.name}</span>
                      <span className="text-sm font-black text-slate-800 dark:text-slate-200">{userSettings.currency} {cat.value.toFixed(2)}</span>
                    </div>
                    <div className="w-full h-2 bg-slate-50 dark:bg-slate-800 rounded-full overflow-hidden">
                      <div 
                        className="h-full rounded-full transition-all duration-1000" 
                        style={{ backgroundColor: COLORS[i % COLORS.length], width: `${Math.min((cat.value / (stats.expense || 1)) * 100, 100)}%` }} 
                      />
                    </div>
                  </div>
                </div>
              ))}
              {categoryData.length === 0 && <p className="text-center text-slate-400 font-bold text-xs py-8 uppercase tracking-widest">Aguardando lançamentos...</p>}
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] border border-slate-100 dark:border-slate-800 shadow-sm overflow-hidden flex flex-col h-full">
          <div className="p-8 flex items-center justify-between border-b border-slate-50 dark:border-slate-800">
            <h3 className="font-black text-slate-800 dark:text-slate-100 uppercase text-xs tracking-widest">Atividade Recente</h3>
          </div>
          <div className="divide-y divide-slate-50 dark:divide-slate-800 flex-1 overflow-y-auto">
            {transactions.slice(0, 8).map(t => (
              <div key={t.id} className="p-6 flex items-center justify-between hover:bg-slate-50/50 dark:hover:bg-slate-800/50 group transition-all">
                <div className="flex items-center gap-4">
                  <div className={`w-10 h-10 rounded-2xl flex items-center justify-center ${t.type === 'income' ? 'bg-emerald-50 text-emerald-500' : 'bg-rose-50 text-rose-500'}`}>
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d={t.type === 'income' ? 'M5 10l7-7m0 0l7 7m-7-7v18' : 'M19 14l-7 7m0 0l-7-7m7 7V3'} />
                    </svg>
                  </div>
                  <div>
                    <p className="text-sm font-black text-slate-800 dark:text-slate-100 leading-tight">{t.description}</p>
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-tight">{t.category}</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <p className={`font-black text-sm text-right ${t.type === 'income' ? 'text-emerald-500' : 'text-slate-800 dark:text-slate-200'}`}>
                    {t.type === 'income' ? '+' : '-'} {t.amount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                  </p>
                  {/* Botão de Edição Rápida no Dashboard */}
                  <button 
                    onClick={(e) => { e.stopPropagation(); /* No dashboard apenas listamos, a edição principal é no extrato por questão de UX */ }}
                    className="p-2 text-slate-200 hover:text-blue-500 hover:bg-blue-50 dark:hover:bg-blue-900/10 rounded-lg opacity-0 group-hover:opacity-100 transition-all active:scale-90"
                    title="Ver detalhes"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                    </svg>
                  </button>
                </div>
              </div>
            ))}
            {transactions.length === 0 && (
              <div className="p-20 text-center opacity-40">
                <svg className="w-12 h-12 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <p className="text-[10px] font-black uppercase tracking-widest">Nada por aqui</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
