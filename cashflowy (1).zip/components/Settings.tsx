
import React, { useRef } from 'react';
import { FinancialState } from '../types';

interface SettingsProps {
  state: FinancialState;
  setState: React.Dispatch<React.SetStateAction<FinancialState>>;
  handleLogout: () => void;
}

const Settings: React.FC<SettingsProps> = ({ state, setState, handleLogout }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const exportData = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(state, null, 2));
    const downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute("href", dataStr);
    downloadAnchorNode.setAttribute("download", `cashflowy_backup_${state.userSettings.name}.json`);
    document.body.appendChild(downloadAnchorNode);
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
  };

  const handleImport = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const json = JSON.parse(e.target?.result as string);
        
        // Validação básica da estrutura do arquivo
        if (json.transactions && json.cards && json.goals && json.userSettings) {
          if (confirm('A importação substituirá todos os seus dados atuais. Deseja continuar?')) {
            setState(json);
            alert('Dados importados com sucesso!');
          }
        } else {
          alert('O arquivo selecionado não é um backup válido do CashFlowy.');
        }
      } catch (err) {
        alert('Erro ao processar o arquivo. Verifique se o formato está correto.');
      }
      // Limpar o valor do input para permitir importar o mesmo arquivo novamente se necessário
      if (fileInputRef.current) fileInputRef.current.value = '';
    };
    reader.readAsText(file);
  };

  const setTheme = (darkMode: boolean) => {
    setState(prev => ({ 
      ...prev, 
      userSettings: { ...prev.userSettings, darkMode } 
    }));
  };

  const toggleFamilyMode = () => {
    setState(prev => ({ 
      ...prev, 
      userSettings: { ...prev.userSettings, familyMode: !prev.userSettings.familyMode } 
    }));
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-20 md:pb-8">
      <div>
        <h2 className="text-2xl font-bold text-slate-800 dark:text-slate-100">Ajustes</h2>
        <p className="text-slate-500 dark:text-slate-400">Personalize sua experiência, {state.userSettings.name}.</p>
      </div>

      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 divide-y divide-slate-100 dark:divide-slate-800 shadow-sm overflow-hidden transition-colors">
        
        <div className="p-8">
          <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100 mb-6">Aparência do Aplicativo</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <button
              onClick={() => setTheme(false)}
              className={`relative p-4 rounded-2xl border-2 transition-all text-left ${!state.userSettings.darkMode ? 'border-blue-600 bg-blue-50/50 dark:bg-blue-900/10' : 'border-slate-100 dark:border-slate-800 hover:border-slate-300'}`}
            >
              <div className="flex items-center gap-3 mb-4">
                <div className={`p-2 rounded-lg ${!state.userSettings.darkMode ? 'bg-blue-600 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-400'}`}>
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 3v1m0 18v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" />
                  </svg>
                </div>
                <span className="font-bold text-slate-800 dark:text-slate-100">Modo Claro</span>
              </div>
            </button>

            <button
              onClick={() => setTheme(true)}
              className={`relative p-4 rounded-2xl border-2 transition-all text-left ${state.userSettings.darkMode ? 'border-blue-600 bg-blue-900/10' : 'border-slate-100 dark:border-slate-800 hover:border-slate-300'}`}
            >
              <div className="flex items-center gap-3 mb-4">
                <div className={`p-2 rounded-lg ${state.userSettings.darkMode ? 'bg-blue-600 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-400'}`}>
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" />
                  </svg>
                </div>
                <span className="font-bold text-slate-800 dark:text-slate-100">Modo Escuro</span>
              </div>
            </button>
          </div>
        </div>

        <div className="p-8">
          <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100 mb-6">Perfil</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-slate-600 dark:text-slate-400 mb-2">Exibição de Nome</label>
              <input
                type="text"
                value={state.userSettings.name}
                onChange={e => setState(prev => ({ ...prev, userSettings: { ...prev.userSettings, name: e.target.value } }))}
                className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-white outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>
        </div>

        <div className="p-8">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100">Modo Família</h3>
              <p className="text-sm text-slate-500 dark:text-slate-400">Sincronize gastos e metas (em breve).</p>
            </div>
            <button
              onClick={toggleFamilyMode}
              className={`w-14 h-8 rounded-full transition-all relative ${state.userSettings.familyMode ? 'bg-blue-600' : 'bg-slate-200 dark:bg-slate-700'}`}
            >
              <div className={`absolute top-1 w-6 h-6 bg-white rounded-full transition-all shadow-sm ${state.userSettings.familyMode ? 'left-7' : 'left-1'}`} />
            </button>
          </div>
        </div>

        <div className="p-8">
          <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100 mb-4">Dados e Backup</h3>
          <div className="flex flex-wrap gap-4 mb-2">
            <button 
              onClick={exportData}
              className="px-6 py-3 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 rounded-xl font-bold hover:bg-slate-50 dark:hover:bg-slate-700 transition-all flex items-center gap-2 shadow-sm"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
              </svg>
              Exportar Backup
            </button>

            <button 
              onClick={() => fileInputRef.current?.click()}
              className="px-6 py-3 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 rounded-xl font-bold hover:bg-slate-50 dark:hover:bg-slate-700 transition-all flex items-center gap-2 shadow-sm"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
              </svg>
              Importar Backup
            </button>
            <input 
              type="file" 
              ref={fileInputRef} 
              onChange={handleImport} 
              accept=".json" 
              className="hidden" 
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settings;
