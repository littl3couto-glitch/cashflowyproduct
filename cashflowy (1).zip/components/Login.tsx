
import React, { useState, useEffect, useRef } from 'react';
import { UserAccount } from '../types';

interface LoginProps {
  onLogin: (username: string) => void;
  isDarkMode: boolean;
}

type AuthStep = 'IDENTIFY' | 'VERIFY';

const BANNED_DOMAINS = [
  'tempmail.com', '10minutemail.com', 'mailinator.com', 'guerrillamail.com', 
  'sharklasers.com', 'temp-mail.org', 'dispostable.com', 'yopmail.com',
  'trashmail.com', 'getnada.com', 'maildrop.cc'
];

const Login: React.FC<LoginProps> = ({ onLogin, isDarkMode }) => {
  const [step, setStep] = useState<AuthStep>('IDENTIFY');
  const [isRegistering, setIsRegistering] = useState(false);
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [error, setError] = useState('');
  const [securityWarning, setSecurityWarning] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [emailValidating, setEmailValidating] = useState(false);
  
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [generatedCode, setGeneratedCode] = useState('');
  const [showMockNotification, setShowMockNotification] = useState(false);
  const otpRefs = useRef<(HTMLInputElement | null)[]>([]);

  const validateEmailFormat = (email: string) => {
    return String(email)
      .toLowerCase()
      .match(/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/);
  };

  const getUserIP = async () => {
    try {
      const response = await fetch('https://api.ipify.org?format=json');
      const data = await response.json();
      return data.ip;
    } catch (e) {
      return '0.0.0.0';
    }
  };

  const generateAndSendCode = () => {
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    setGeneratedCode(code);
    setShowMockNotification(true);
    setTimeout(() => setShowMockNotification(false), 8000);
  };

  const handleInitialSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSecurityWarning('');
    setIsLoading(true);

    // --- LOGICA DE ADMIN PERMANENTE ---
    if (!isRegistering && username === 'adm' && password === 'adm') {
      // Cria a conta admin se ela não existir no sistema para garantir persistência
      const users: UserAccount[] = JSON.parse(localStorage.getItem('cashflowy_accounts') || '[]');
      if (!users.find(u => u.username === 'adm')) {
        const adminAccount: UserAccount = {
          username: 'adm',
          email: 'adm',
          passwordHash: 'adm',
          settings: { name: 'Administrador Mestre', currency: 'R$', familyMode: true, darkMode: true }
        };
        localStorage.setItem('cashflowy_accounts', JSON.stringify([...users, adminAccount]));
      }
      onLogin('adm');
      setIsLoading(false);
      return;
    }

    const userIp = await getUserIP();
    const ipLedger = JSON.parse(localStorage.getItem('cashflowy_ip_ledger') || '{}');

    if (isRegistering) {
      if (ipLedger[userIp]) {
        setSecurityWarning('ALERTA CRÍTICO: Já existe uma conta vinculada a este IP. Criar múltiplas contas viola nossos termos de uso. O descumprimento resultará no BANIMENTO de todos os perfis, perda do acesso ao produto e de qualquer saldo financeiro registrado.');
        setIsLoading(false);
        return;
      }

      if (!validateEmailFormat(email)) {
        setError('Por favor, utilize um formato de e-mail válido.');
        setIsLoading(false);
        return;
      }

      const domain = email.split('@')[1]?.toLowerCase();
      if (BANNED_DOMAINS.includes(domain)) {
        setError('E-mails temporários não são permitidos.');
        setIsLoading(false);
        return;
      }

      setEmailValidating(true);
      await new Promise(resolve => setTimeout(resolve, 1000));
      setEmailValidating(false);

      const users: UserAccount[] = JSON.parse(localStorage.getItem('cashflowy_accounts') || '[]');
      if (users.find(u => u.username === username || u.email === email)) {
        setError('Este usuário ou e-mail já está em uso.');
        setIsLoading(false);
        return;
      }
    } else {
      const users: UserAccount[] = JSON.parse(localStorage.getItem('cashflowy_accounts') || '[]');
      const user = users.find(u => u.username === username && u.passwordHash === password);
      if (!user) {
        setError('Credenciais inválidas.');
        setIsLoading(false);
        return;
      }
    }

    setTimeout(() => {
      generateAndSendCode();
      setStep('VERIFY');
      setIsLoading(false);
    }, 800);
  };

  const handleOtpChange = (index: number, value: string) => {
    if (!/^\d*$/.test(value)) return;
    const newOtp = [...otp];
    newOtp[index] = value.slice(-1);
    setOtp(newOtp);
    if (value && index < 5) otpRefs.current[index + 1]?.focus();
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && !otp[index] && index > 0) otpRefs.current[index - 1]?.focus();
  };

  const handleVerify = async () => {
    const enteredCode = otp.join('');
    if (enteredCode !== generatedCode) {
      setError('Código incorreto.');
      return;
    }

    if (isRegistering) {
      const userIp = await getUserIP();
      const ipLedger = JSON.parse(localStorage.getItem('cashflowy_ip_ledger') || '{}');
      ipLedger[userIp] = username;
      localStorage.setItem('cashflowy_ip_ledger', JSON.stringify(ipLedger));

      const users: UserAccount[] = JSON.parse(localStorage.getItem('cashflowy_accounts') || '[]');
      const newUser: UserAccount = {
        username,
        email,
        passwordHash: password,
        settings: {
          name: name || username,
          currency: 'R$',
          familyMode: false,
          darkMode: isDarkMode
        }
      };
      localStorage.setItem('cashflowy_accounts', JSON.stringify([...users, newUser]));
      onLogin(username);
    } else {
      onLogin(username);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-slate-50 dark:bg-slate-950 transition-colors relative overflow-hidden font-sans">
      {showMockNotification && (
        <div className="fixed top-6 left-1/2 -translate-x-1/2 z-[100] w-[90%] max-w-sm bg-slate-900 dark:bg-white text-white dark:text-slate-900 px-6 py-5 rounded-[2rem] shadow-2xl flex items-center gap-4 animate-in slide-in-from-top-10 duration-500 border border-white/10 dark:border-slate-200">
          <div className="w-12 h-12 bg-blue-600 rounded-2xl flex items-center justify-center flex-shrink-0 animate-pulse">
            <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
            </svg>
          </div>
          <div className="flex-1">
            <p className="text-[10px] font-black uppercase tracking-widest text-blue-500 mb-0.5">E-mail de Verificação</p>
            <p className="text-sm font-bold leading-tight">Use o código: <span className="text-blue-600 dark:text-blue-500 text-lg">{generatedCode}</span></p>
          </div>
        </div>
      )}

      <div className="w-full max-w-md relative z-10">
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-blue-600 rounded-[2.5rem] text-white shadow-2xl shadow-blue-200 dark:shadow-blue-900/20 mb-6 transition-transform hover:rotate-3">
            <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <h1 className="text-4xl font-black text-slate-800 dark:text-white tracking-tighter">CashFlowy</h1>
          <p className="text-slate-500 dark:text-slate-400 mt-2 font-semibold tracking-wide uppercase text-[10px]">Autenticação Segura</p>
        </div>

        <div className="bg-white dark:bg-slate-900 p-8 md:p-10 rounded-[3rem] border border-slate-200 dark:border-slate-800 shadow-2xl">
          {step === 'IDENTIFY' ? (
            <>
              <div className="mb-8">
                <h2 className="text-2xl font-black text-slate-800 dark:text-white mb-2">
                  {isRegistering ? 'Criar Perfil' : 'Acesso à Conta'}
                </h2>
              </div>

              <form onSubmit={handleInitialSubmit} className="space-y-5">
                {isRegistering && (
                  <div>
                    <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Seu Nome</label>
                    <input
                      type="text"
                      required
                      value={name}
                      onChange={e => setName(e.target.value)}
                      className="w-full px-6 py-4 rounded-2xl border border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-white outline-none focus:ring-2 focus:ring-blue-500 transition-all font-medium"
                      placeholder="Nome completo"
                    />
                  </div>
                )}

                {isRegistering && (
                  <div className="relative">
                    <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">E-mail</label>
                    <div className="relative">
                      <input
                        type="email"
                        required
                        value={email}
                        onChange={e => setEmail(e.target.value)}
                        className={`w-full px-6 py-4 rounded-2xl border ${error.includes('e-mail') ? 'border-rose-500' : 'border-slate-100 dark:border-slate-800'} bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-white outline-none focus:ring-2 focus:ring-blue-500 transition-all font-medium`}
                        placeholder="exemplo@gmail.com"
                      />
                      {emailValidating && (
                        <div className="absolute right-4 top-1/2 -translate-y-1/2">
                          <div className="w-5 h-5 border-2 border-blue-600/30 border-t-blue-600 rounded-full animate-spin" />
                        </div>
                      )}
                    </div>
                  </div>
                )}

                <div>
                  <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Username</label>
                  <input
                    type="text"
                    required
                    value={username}
                    onChange={e => setUsername(e.target.value.toLowerCase().trim())}
                    className="w-full px-6 py-4 rounded-2xl border border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-white outline-none focus:ring-2 focus:ring-blue-500 transition-all font-medium"
                    placeholder="usuario"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Senha</label>
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    className="w-full px-6 py-4 rounded-2xl border border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-white outline-none focus:ring-2 focus:ring-blue-500 transition-all font-medium"
                    placeholder="••••••••"
                  />
                </div>

                {error && (
                  <div className="text-sm font-bold text-rose-500 bg-rose-50 dark:bg-rose-950/30 p-4 rounded-2xl border border-rose-100 animate-in fade-in zoom-in-95">
                    {error}
                  </div>
                )}

                {securityWarning && (
                  <div className="p-5 bg-rose-600 text-white rounded-[2rem] shadow-xl border border-rose-400 animate-pulse">
                    <p className="text-[11px] leading-tight font-black">{securityWarning}</p>
                  </div>
                )}

                <button
                  type="submit"
                  disabled={isLoading || !!securityWarning || emailValidating}
                  className="w-full py-5 bg-blue-600 text-white font-black text-lg rounded-[2rem] hover:bg-blue-700 shadow-2xl shadow-blue-200 dark:shadow-none transition-all active:scale-95 disabled:opacity-50 flex items-center justify-center gap-3"
                >
                  {isLoading ? (
                    <div className="w-6 h-6 border-3 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : (
                    isRegistering ? 'Criar Conta' : 'Entrar'
                  )}
                </button>
              </form>
            </>
          ) : (
            <div className="animate-in fade-in slide-in-from-right-10 duration-500">
              <button 
                onClick={() => setStep('IDENTIFY')}
                className="mb-6 text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 flex items-center gap-2 text-xs font-black uppercase"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M15 19l-7-7 7-7" />
                </svg>
                Voltar
              </button>
              <h2 className="text-3xl font-black text-slate-800 dark:text-white mb-3">Verifique seu e-mail</h2>
              <p className="text-slate-500 dark:text-slate-400 text-sm mb-10 leading-relaxed">
                Código enviado para <span className="font-bold text-blue-600">{email}</span>.
              </p>
              <div className="flex justify-between gap-3 mb-10">
                {otp.map((digit, i) => (
                  <input
                    key={i}
                    ref={el => { otpRefs.current[i] = el; }}
                    type="text"
                    maxLength={1}
                    value={digit}
                    onChange={e => handleOtpChange(i, e.target.value)}
                    onKeyDown={e => handleKeyDown(i, e)}
                    className="w-full h-16 text-center text-2xl font-black rounded-2xl border-2 border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-white focus:ring-4 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all"
                  />
                ))}
              </div>
              <button
                onClick={handleVerify}
                className="w-full py-5 bg-blue-600 text-white font-black text-lg rounded-[2rem] shadow-2xl transition-all active:scale-95 flex items-center justify-center"
              >
                Verificar Código
              </button>
            </div>
          )}

          {step === 'IDENTIFY' && (
            <div className="mt-10 pt-8 border-t border-slate-50 dark:border-slate-800 text-center">
              <button
                onClick={() => { setIsRegistering(!isRegistering); setError(''); setSecurityWarning(''); }}
                className="text-sm font-black text-blue-600 dark:text-blue-400 hover:text-blue-800 uppercase tracking-widest"
              >
                {isRegistering ? 'Já tem conta? Entrar' : 'Novo por aqui? Criar Perfil'}
              </button>
            </div>
          )}
        </div>
        <p className="mt-10 text-center text-slate-400 text-[10px] font-black uppercase tracking-[0.2em]">
          CashFlowy &copy; {new Date().getFullYear()} • Sistema Administrador Ativo
        </p>
      </div>
    </div>
  );
};

export default Login;
