
import React from 'react';

const RendaPaz: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-20 md:pb-8">
      <div className="relative overflow-hidden rounded-[2.5rem] bg-gradient-to-br from-emerald-500 to-teal-700 p-8 md:p-16 text-white shadow-2xl">
        <div className="relative z-10 flex flex-col items-center text-center space-y-8">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-white/20 backdrop-blur-md rounded-3xl mb-4">
            <svg className="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
            </svg>
          </div>
          
          <div className="space-y-4">
            <h1 className="text-4xl md:text-6xl font-black tracking-tight">Renda da Paz</h1>
            <p className="text-xl md:text-2xl font-medium text-emerald-50 max-w-2xl opacity-90 leading-relaxed">
              Descubra a tranquilidade de investir com propósito. Conheça nosso Auxiliar de Investimentos Inteligente e mude sua relação com o dinheiro.
            </p>
          </div>

          <a 
            href="https://dynamic-mermaid-c2c5d3.netlify.app/" 
            target="_blank" 
            rel="noopener noreferrer"
            className="group relative inline-flex items-center gap-3 bg-white text-emerald-700 px-10 py-5 rounded-2xl font-bold text-lg shadow-xl hover:bg-emerald-50 transition-all hover:scale-105 active:scale-95"
          >
            Conhecer Assistente
            <svg className="w-6 h-6 transition-transform group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
            </svg>
          </a>
        </div>

        {/* Abstract background elements */}
        <div className="absolute top-0 right-0 -mr-20 -mt-20 w-80 h-80 bg-white/10 rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-80 h-80 bg-emerald-400/20 rounded-full blur-3xl" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <FeatureCard 
          icon="🛡️" 
          title="Segurança" 
          description="Estratégias focadas em preservação de capital e crescimento sólido."
        />
        <FeatureCard 
          icon="🧘" 
          title="Tranquilidade" 
          description="Investimentos que não tiram o seu sono. Planejamento de longo prazo."
        />
        <FeatureCard 
          icon="⚡" 
          title="Inteligência" 
          description="Uso de tecnologia de ponta para analisar os melhores cenários para você."
        />
      </div>
    </div>
  );
};

const FeatureCard: React.FC<{ icon: string, title: string, description: string }> = ({ icon, title, description }) => (
  <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm transition-all hover:shadow-md">
    <div className="text-4xl mb-4">{icon}</div>
    <h3 className="text-xl font-bold text-slate-800 dark:text-slate-100 mb-2">{title}</h3>
    <p className="text-slate-500 dark:text-slate-400 leading-relaxed">{description}</p>
  </div>
);

export default RendaPaz;
